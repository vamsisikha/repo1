/**
 * 
 */
package com.metlife.gssp.metlife_GSSP.core;
import javax.jcr.Session;
//import com.day.cq.search.Query;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;

import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import java.util.HashMap;
import java.util.Map;
/**
 * @author nisha
 * class implementing the service APdfQueryService
 *
 */

@Component(immediate=true)

@Service
public class APdfQueryServiceImpl implements APdfQueryService {
	
	private static final Logger LOGEER = LoggerFactory.getLogger(APdfQueryServiceImpl.class);
	QueryResult result = null;
	
	@Reference 
    private ResourceResolverFactory resourceFactory;
	
	@Override
	public QueryResult queryResult(Session pSession, String pPath) {
		
		try {
		QueryManager queryManager = pSession.getWorkspace().getQueryManager();
		LOGEER.info("Executing the Query to get results ");
		Query query = queryManager.createQuery("select * from [dam:Asset] where jcr:path like '" + pPath + "%'", Query.SQL);
		result = ((javax.jcr.query.Query) query).execute();
		
		} 
		catch (Exception lError) {
			LOGEER.error("queryResult = Error during exceuting JCR Query = ", lError);
		}
		/*finally {
			if (pSession != null) {
				pSession.logout();
			System.out.println("inside finally block");
				}
			}*/
		LOGEER.info("Query Executed Successfully ");
		return result;
		}
	
	@Activate
	public void listTitles() {
		Map<String,Object> paramMap = new HashMap<String,Object>();
        //Mention the subServiceName you had used in the User Mapping
        paramMap.put(ResourceResolverFactory.SUBSERVICE, "APdfQueryService");
        LOGEER.info("After the param");
        ResourceResolver rr = null;
        try{
              rr = resourceFactory.getServiceResourceResolver(paramMap);
              LOGEER.info("UserId : " + rr.getUserID());
              
              //return rr;
        }
        catch(Exception e){
        	LOGEER.error(e.getMessage());
      }
        
	}
	
	
	//additional test for pwd if you dont want comment it and accordingly you can map it if you need.
	//private String username = new String("admin");
	//private String password = new String("admin");
	
	public ResourceResolver getUserResourceResolver(){
	   //String unprotectedPass = null; if you want to set pwd to map object.
		
		Map<String,Object> paramMapobj = new HashMap<String,Object>();
		paramMapobj.put(ResourceResolverFactory.SUBSERVICE, "APdfQueryService");
	
        LOGEER.info("After the param");
      ResourceResolver rr = null;
      try{
              
        	rr = resourceFactory.getServiceResourceResolver(paramMapobj);
            LOGEER.info("UserId : " + rr.getUserID());
            LOGEER.info("Resource resolver of service is : " + rr);
            
            
           }
        catch(Exception e){
        	LOGEER.error(e.getMessage());
      }
		return rr;
		
	}

}
