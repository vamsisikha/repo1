/**
 * 
 */
package com.metlife.gssp.metlife_GSSP.core;
import java.util.ArrayList;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.Session;
import javax.jcr.query.QueryResult;

import org.apache.felix.scr.annotations.Reference;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.dam.api.AssetManager;
import com.metlife.gssp.metlife_GSSP.core.APdfQueryService;
/**
 * @author : nisha
 *
 */
public class PdfQueryResult extends WCMUsePojo{
	
private static final Logger LOG = LoggerFactory.getLogger(PdfQueryResult.class);
     
	private String AssetPath;
	
	List<PdfBean> multiList = null;
	
    Session lSession = null;
	
   /*    @Reference
    APdfQueryService serviceobj;*/
    
    @Override
	public void activate() {
		multiList = new ArrayList<PdfBean>();
		// making service object for consuming it.
		APdfQueryService serviceobj = getSlingScriptHelper().getService(APdfQueryService.class);
		LOG.info("service object value is " + serviceobj);
		
		//additonal test for service mapped user
		serviceobj.getUserResourceResolver();
		LOG.info("resolver object value is " + serviceobj.getUserResourceResolver());
		
		//below code is for getting the authored path value.
		AssetPath = this.getProperties().get("assetpath", "");
		
		try{
			
		//additonal test and generic way of getting resource resolver
		//ResourceResolver resourceResolver = getResourceResolver();
			
		ResourceResolver resourceResolver = serviceobj.getUserResourceResolver();
		LOG.info("resolver object from mapped service is " + resourceResolver);
		
		AssetManager lAssetmanager = resourceResolver.adaptTo(AssetManager.class);
		lSession = resourceResolver.adaptTo(Session.class);
		LOG.info(" Asset QUERY PATH is : " + this.AssetPath);
		LOG.info("session is"+lSession.toString());
		
		// additional test for checking the service object nullability.
		if (lSession != null) {
			if(serviceobj==null){
				LOG.info("service object is " + serviceobj);
			}
			
			
			QueryResult lResult =serviceobj.queryResult(lSession,AssetPath);
			LOG.info("lresult is"+ lResult);
			LOG.info("lresult string is"+ lResult.toString());
			NodeIterator it = lResult.getNodes();
			while (it.hasNext()) {
				LOG.info("while blockMMMMMMM");
				System.out.println("while blockMMMMMMM");
			PdfBean bean = new PdfBean();
			Node node = (Node) it.next();
			LOG.info("NODE NAME :: " + node.getName());
			Resource lRes = resourceResolver.getResource(node.getPath());
			Resource lMetadataRes = lRes.getChild("jcr:content/metadata");
			ModifiableValueMap lMetadata = lMetadataRes.adaptTo(ModifiableValueMap.class);
			if (lMetadata.get("dc:title") != null ||lMetadata.get("dc:subject") != null)
			{
			   bean.setPdfTitle(lMetadata.get("dc:title").toString());
			   bean.setPdfSubject(lMetadata.get("dc:subject").toString());
			   bean.setPdfPath(node.getPath());
			   
			}
			multiList.add(bean);
			
			LOG.info("LIST IS HAVING:: " + multiList);
			
			
			}
			
			
			
			} 
		else {
			LOG.info("createPixelAsset :: Session in null, can't execute the query");
			}
		
		}
		
		catch (Exception lError) {
			LOG.error("createPixelAsset :: Error while creating a Pixel asset", lError);
			} 
		
		/*finally {
			if (lSession != null) {
			lSession.logout();
			System.out.println("inside finally block");
				}
			} */
		
		LOG.info("admin details here below::::");
		
		//additional test for method service mapping user.
		serviceobj.listTitles();
	}
	
	public List<PdfBean> getMultiList() {
		return multiList;
	}

	public void setMultiList(List<PdfBean> multiList) {
		this.multiList = multiList;
	}
	

}
