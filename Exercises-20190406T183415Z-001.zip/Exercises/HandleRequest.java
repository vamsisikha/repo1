package com.metlife.refresh.core.migrator.services;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.ServerException;
import java.util.HashMap;
import java.util.Map;
import org.apache.felix.scr.annotations.Component;
import javax.jcr.LoginException;
import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.jcr.api.SlingRepository;
import com.metlife.refresh.core.migrator.impl.AEMContextImpl;
import com.metlife.refresh.core.migrator.util.SiteProcessor;

import com.adobe.granite.crypto.CryptoException;
import com.adobe.granite.crypto.CryptoSupport;
/**
 * Created By : 
 * @author Sanjay Kumar
 *
 */

@Component(immediate = true, metatype = true, name = "com.metlife.refresh.core.migrator.services.HandleRequest", label = "HandleRequest", description = " A small test servlet")

@SlingServlet(name = "HandleRequest", paths = "/bin/HandleRequest", methods = "POST", metatype = true, generateComponent = false)
@Service(value = HandleRequest.class)
public class HandleRequest extends org.apache.sling.api.servlets.SlingAllMethodsServlet {
	private static final long serialVersionUID = 2598426539166789515L;

	@Reference
	private SlingRepository repository;

	public void bindRepository(SlingRepository repository) {
		this.repository = repository;
	}

	@Reference
	private ResourceResolverFactory resolverFactory;
	private ResourceResolver resourceResolver;
	private Resource resource;
	
	@Reference
	private ResourceResolverFactory resourceFact;

	@Reference
	private CryptoSupport cryptoSupport;

	private String username = new String("admin");
	private String password = new String("admin");

	private Session session = null;

	private ResourceResolver getUserResourceResolver()
			throws LoginException, org.apache.sling.api.resource.LoginException {
		Map<String, Object> authenticationInfo = new HashMap<String, Object>(2);
		authenticationInfo.put(ResourceResolverFactory.USER, username);
		String unprotectedPass = null;
	/*	try {
			unprotectedPass = cryptoSupport.unprotect(password);
		} catch (CryptoException e) {
			unprotectedPass = password;
			System.out.println("Error!!!!");
		}*/
		unprotectedPass = password;
		authenticationInfo.put(ResourceResolverFactory.PASSWORD, unprotectedPass.toCharArray());
		authenticationInfo.put(ResourceResolverFactory.SUBSERVICE, "datawrite");
		return resourceFact.getResourceResolver(authenticationInfo);
	}

	public ResourceResolver getAEMContext() throws LoginException, org.apache.sling.api.resource.LoginException {

		this.resourceResolver = getUserResourceResolver();
		return this.resourceResolver;
	}

	private Session getSession() throws RepositoryException, Exception {
		resourceResolver = getAEMContext();
		session = resourceResolver.adaptTo(Session.class);
		return session;

	}

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServerException, IOException {
		 doPost( request,  response);
	}
	
	
	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServerException, IOException {
		System.out.println("Came Inside HandleRequest Sling Servlet");
		SiteProcessor site = new SiteProcessor();
		String fileName = null ; 
		String logPath = null; 
		BufferedReader buffReader = null;
		
		try {
			fileName = request.getParameter("filename");
			if(fileName!=null){
				resourceResolver = getAEMContext();
				System.out.println("#################### xmlPath reading started");
				Resource resourcenew=resourceResolver.getResource("/apps/refresh/config/metlife.migrator");
				ValueMap props= resourcenew.adaptTo(ValueMap.class);
				String xmlPath= props.get("xmlPath").toString(); 
				logPath = props.get("logPath").toString(); 
				xmlPath = xmlPath + "\\" + fileName ;
				System.out.println("#################### xmlPath"+xmlPath);
				System.out.println("#################### logPath"+logPath);
			 	site.generateSite(xmlPath,resourceResolver);
			}
			
			response.setContentType("text/html");
			String sCurrentLine;
			String temp = new String() ; 
			buffReader = new BufferedReader(new FileReader(logPath));
			while ((sCurrentLine = buffReader.readLine()) != null) {
				temp = temp + "\n" +sCurrentLine;
			} 
                System.out.println("****************************************************************************************************************");
                System.out.println(temp);
                System.out.println("****************************************************************************************************************");
                response.getWriter().write(temp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}