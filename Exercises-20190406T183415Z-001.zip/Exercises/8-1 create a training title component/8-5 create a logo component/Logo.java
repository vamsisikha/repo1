package apps.training.components.logo;

import com.day.text.Text;
import com.day.cq.wcm.foundation.Image;
import com.day.cq.wcm.foundation.Q.*;
import com.day.cq.commons.Doctype;
import com.adobe.cq.sightly.WCMUse;
import org.apache.sling.api.resource.Resource;

public class Logo extends WCMUse {
	private Image img;

    public void activate() throws Exception {
        //Get the logo resource
        Resource res = getCurrentStyle().getDefiningResource("fileReference");
        if (res == null) {
            res = getCurrentStyle().getDefiningResource("file");
        }

        //Create the logo image
        if (res != null) {
            img = new Image(res);
            img.setItemName(Image.NN_FILE, "image");
            img.setItemName(Image.PN_REFERENCE, "imageReference");
            img.setSelector("img");
        }
    }

    //returns the logo image
    public Image getLogo() {
        return img;
    }

    //returns the home url
    public String getHomeUrl(){
		return getCurrentPage().getAbsoluteParent(2).getPath() + ".html";
    }

}

