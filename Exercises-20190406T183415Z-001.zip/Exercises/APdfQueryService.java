/**
 * 
 */
package com.metlife.gssp.metlife_GSSP.core;
import javax.jcr.query.Query;
import javax.jcr.query.QueryResult;

import org.apache.sling.api.resource.ResourceResolver;

import javax.jcr.Session;
/**
 * @author nisha
 *  interface class for APdfQueryServiceImpl service.
 *
 */
public interface APdfQueryService {
	public QueryResult queryResult(Session pSession, String pPath);
	public void listTitles();
	//additional test for getting service specific resource resolver.
	public ResourceResolver getUserResourceResolver();

}




